package com.marmitech.Marmitech;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MarmitechApplication {

	public static void main(String[] args) {
		SpringApplication.run(MarmitechApplication.class, args);
	}


}
