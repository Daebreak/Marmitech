package com.marmitech.Marmitech.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.marmitech.Marmitech.Entity.HistoricoCompra;

public interface HistoricoCompraRepository extends JpaRepository<HistoricoCompra, Integer>{

}
